import java.lang.invoke.StringConcatFactory;

public class Produto {
    private String nome;
    private String codigo;
    private double preco;
    private int quantidade;

    public Produto(String nome, String codigo, double preco, int quantidade) {
        this.nome = nome;
        this.codigo = codigo;
        this.preco = preco;
        this.quantidade = quantidade;
    }

    public String getNome() {
        return nome;
    }

    public String getCodigo() {
        return codigo;
    }

    public double getpreco() {
        return preco;
    }

    public int getquantidade() {
        return quantidade;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public void exibirinformacoes() {
        System.out.println("código: " + codigo + " | Nome: " + nome + " | Preço: R$" + preco + " | Quantidade: " + quantidade);
    }

    public double valorTotal() {
        return preco * quantidade;
    }

}





