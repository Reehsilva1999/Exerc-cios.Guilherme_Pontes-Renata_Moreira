import java.util.ArrayList;
import java.util.Scanner;

public class EstoqueMercado {
public static void main(String[] args){
    Scanner scanner = new Scanner(System.in);
    ArrayList<Produto> estoque = new ArrayList<>();

    int opcao;

    do {
        System.out.println("n=== MENU ESTOQUE ===");
        System.out.println("1 - Adicionar produto");
        System.out.println("2 - Atualizar produto");
        System.out.println("3 - Remover produto");
        System.out.println("4 - Listar produtos");
        System.out.println("5 - Sair");
        System.out.println("Escolha uma opção para continuar: ");
        opcao = scanner.nextInt();
        scanner.nextLine();

        switch (opcao) {
            case 1:
                System.out.print("Nome: ");
                String nome = scanner.nextLine();

                System.out.print("código: ");
                String codigo = scanner.nextLine();

                System.out.print("Preço: ");
                double preco = scanner.nextDouble();

                System.out.print("Quantidade: ");
                int quantidade = scanner.nextInt();
                scanner.nextLine();

                Produto novo = new Produto(nome, codigo, preco, quantidade);
                estoque.add(novo);
                System.out.println("Produto adicionado!");
                break;

            case 2:
                System.out.print("Digite o codigo do preoduto para atualizar: ");
                String codigoAtualizar = scanner.nextLine();
                boolean encontrado = false;

                for (Produto p : estoque) {
                    if (p.getCodigo().equals(codigoAtualizar)) {
                        System.out.print("Nome novo: ");
                        p.setNome(scanner.nextLine());

                        System.out.print("Preço novo: ");
                        p.setPreco(scanner.nextDouble());
                        System.out.print("Quantidade nova: ");
                        p.setQuantidade(scanner.nextInt());
                        scanner.nextLine();
                        System.out.print("Produto atualizado com sucesso!");
                        encontrado = true;
                        break;
                    }
                }
                if (!encontrado) {
                    System.out.println("Produto não foi encontrado.");
                }
                break;

            case 3:
                System.out.print("Digite o código do produto para remove-ló: ");
                String codigoRemover = scanner.nextLine();
                boolean removido = estoque.removeIf(p -> p.getCodigo().equals(codigoRemover));
                System.out.println("Produto removido, Produto não encontrado.");
                break;

            case 4:

                System.out.print("\n--- ESTOQUE ATUAL ---");
                double totalEstoque = 0;
                for (Produto p : estoque) {
                    p.exibirinformacoes();
                }
                System.out.printf("Valor total em estoque: R$ %.2f\n", totalEstoque);
                break;

            case 5:
                System.out.println("Sistema encerrado...!");
                break;

            default:
                System.out.println("Opção inválida.");
        }
    }while (opcao != 5);
    scanner.close();











}























}
